﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeshGen_Base : MonoBehaviour
{
    public virtual void BuildMesh() {}
}
